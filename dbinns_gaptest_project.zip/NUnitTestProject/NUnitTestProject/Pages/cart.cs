﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;

using System;
using System.Collections.Generic;
using System.Text;

namespace dbinns_framework.Pages
{
    class cart
    {
        static By pageMain = By.XPath("//div[@id='primary']//main[@id='main']");
        static By cartTitle = By.XPath("//h1[@class='entry-title']");
        static By productPrice = By.XPath("//p//span[@class='woocommerce-Price-amount amount']");
        static By quantityInput = By.XPath("//div[@class='quantity']//input");
        static By cartCount = By.XPath("//a[@class='cart-contents']//span[@class='count']");

        static By productCount = By.XPath("//td[@class='product-quantity']//input");
        static By cartPrice = By.XPath("(//td[@class='product-subtotal']//span)[1]");
        static String cartProduct = "//td[@class='product-name']//a[contains(., '{0}')]";

        static By couponCodeIput = By.XPath("//input[@id='coupon_code']");
        static By applyBtn = By.XPath("//div[@class='coupon']//button[@type='submit']");
        static By successMessage = By.XPath("//div[@class='woocommerce-message' and contains(., 'Coupon code applied successfully')]");
        static By cartSubtotal = By.XPath("//td[@data-title='Subtotal']/span");
        static By cartRate = By.XPath("//ul[@id='shipping_method']//following-sibling::span");
        static By couponDiscount = By.XPath("//td[contains(@data-title, 'Coupon')]/span");

        static By totalOrder = By.XPath("//tr[@class='order-total']//td[contains(@data-title, 'Total')]//strong/span");



        public static bool isPageLoaded(IWebDriver driver)
        {
            var pageLoaded = driver.FindElement(pageMain).Displayed;
            var titleLoaded = base_framework.FindElement(driver, cartTitle, 10).Displayed;

            return pageLoaded & titleLoaded;
        }

        public static bool isProductTitleDisplayed(IWebDriver driver)
        {
            return driver.FindElement(cartTitle).Displayed;
        }
        public static bool isProductPriceDisplayed(IWebDriver driver)
        {
            return driver.FindElement(productPrice).Displayed;
        }

        public static void setQuantity(IWebDriver driver, int quantity)
        {
            IWebElement qttyInput = base_framework.FindElement(driver, quantityInput, 10);
            //IWebElement qttyInput = driver.FindElement(quantityInput);
            qttyInput.Clear();
            qttyInput.SendKeys(quantity.ToString());
        }

        public static String returnQuantityFieldText(IWebDriver driver)
        {
            IWebElement qttyInput = base_framework.FindElement(driver, quantityInput, 5);
            return qttyInput.GetAttribute("value");
        }


        public static String returnCartItemsQuantity(IWebDriver driver)
        {
            IWebElement cartCountEl = base_framework.FindElement(driver, cartCount, 5);
            return cartCountEl.Text.Split(" ")[0];
        }

     

        public static bool productExists(IWebDriver driver, String name)
        {
            return base_framework.FindElement(driver, By.XPath(String.Format(cartProduct,name)), 5).Displayed;
            //return productEl.Displayed();
        }

        public static String returnPrice(IWebDriver driver)
        {
            IWebElement priceEl= base_framework.FindElement(driver, cartPrice, 5);
            return priceEl.Text;
        }

        public static String returnCount(IWebDriver driver)
        {   
            IWebElement countEl = base_framework.FindElement(driver, productCount, 5);
            return countEl.GetAttribute("value");
        }

        public static void fillCoupon(IWebDriver driver, String text)
        {
            base_framework.sendKeys(driver, couponCodeIput, text, false, 5);
        }

        public static String returnCouponCodeText(IWebDriver driver)
        {
            return base_framework.FindElement(driver, couponCodeIput, 5).Text;
        }

        public static void clickApply(IWebDriver driver)
        {
            base_framework.FindElement(driver, applyBtn, 5).Click();
        }
        public static bool isCouponAppliedMessageVisible(IWebDriver driver)
        {
            return base_framework.FindElement(driver, successMessage, 5).Displayed;
        }

        public static String returnFinalTotal(IWebDriver driver)
        {
            return base_framework.FindElement(driver, totalOrder, 5).Text;
        }



    }
}

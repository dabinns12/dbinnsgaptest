﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;

using System;
using System.Collections.Generic;
using System.Text;

namespace dbinns_framework.Pages
{
    class search_results
    {
        static By searchResultsText = By.XPath("//main[@id='main']//h1[contains(.,'Search results')]");
        static By searchInput = By.XPath("//input[@id='woocommerce-product-search-field-0']");
        static By searchResultItems = By.XPath("//ul[contains(@class,'products')]//following-sibling::li");
        static String searchResultItem = "//ul[contains(@class,'products')]//following-sibling::li//h2[contains(.,'{0}')]";
        



        public static bool isPageLoaded(IWebDriver driver)
        {
            return base_framework.FindElement(driver, searchResultsText, 5).Displayed;
        }

        public static bool isSearchBoxDisplayed(IWebDriver driver)
        {
            return base_framework.FindElement(driver, searchInput, 5).Displayed;

        }

        public static void searchProduct(IWebDriver driver, String text)
        {
            base_framework.sendKeys(driver, searchInput, text, true, 5);

        }

        public static String returnsearchFieldText(IWebDriver driver)
        {
            return base_framework.FindElement(driver, searchInput, 5).GetAttribute("value");

        }

        public static int returnSearchResultsQuantity(IWebDriver driver)
        {
            return driver.FindElements(searchResultItems).Count;

        }

        public static void clickItemByName(IWebDriver driver, String name)
        {
            base_framework.FindElement(driver, By.XPath(String.Format(searchResultItem,name)), 5).Click();
            //return driver.FindElements(searchResultItem).Count;

        }


    }
}

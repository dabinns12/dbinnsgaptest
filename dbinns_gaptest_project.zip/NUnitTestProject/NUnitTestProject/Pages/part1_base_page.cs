﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;

using System;
using System.Collections.Generic;
using System.Text;

namespace dbinns_framework
{
    class part1_base_page
    {
        static By searchBar = By.XPath("//div[5]/table/*[@id='search_bar']");
        static By bookTitle = By.XPath("//div[3]/table/*[@class='book_title']");

        public static int isPageLoaded()
        {
            return 0;
        }

        public static void searchBook(IWebDriver driver, String text)
        {
            IWebElement bar = driver.FindElement(part1_base_page.searchBar);
            bar.Clear();
            bar.SendKeys(text);
        }

        public static String returnBookTitle(IWebDriver driver)
        {
            IWebElement searchResult = driver.FindElement(bookTitle);
            return searchResult.Text;
        }
    }
}

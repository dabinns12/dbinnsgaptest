﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;

using System;
using System.Collections.Generic;
using System.Text;

namespace dbinns_framework.Pages
{
    class product
    {
        static By pageMain = By.XPath("//div[@id='primary']//main[@id='main']");
        static By productTitle = By.XPath("//h1[@class='product_title entry-title']");
        static By productPrice = By.XPath("//p//span[@class='woocommerce-Price-amount amount']");
        static By quantityInput = By.XPath("//div[@class='quantity']//input");
        static By addToCartBtn = By.XPath("//form[@class='cart']//button");
        static By cartCount = By.XPath("//a[@class='cart-contents']//span[@class='count' and contains(.,'item')]");
        static By CartMenu = By.XPath("//li[@id='menu-item-815']");
        



        public static bool isPageLoaded(IWebDriver driver)
        {
            var pageLoaded = driver.FindElement(pageMain).Displayed;
            var priceLoaded = driver.FindElement(productPrice).Displayed;
            var titleLoaded = driver.FindElement(productTitle).Displayed;

            return pageLoaded & priceLoaded & titleLoaded;
        }

        public static bool isProductTitleDisplayed(IWebDriver driver)
        {
            return driver.FindElement(productTitle).Displayed;
        }
        public static bool isProductPriceDisplayed(IWebDriver driver)
        {
            return driver.FindElement(productPrice).Displayed;
        }

        public static void setQuantity(IWebDriver driver, int quantity)
        {
            IWebElement qttyInput = base_framework.FindElement(driver, quantityInput, 10);
            //IWebElement qttyInput = driver.FindElement(quantityInput);
            qttyInput.Clear();
            qttyInput.SendKeys(quantity.ToString());
        }

        public static String returnQuantityFieldText(IWebDriver driver)
        {
            IWebElement qttyInput = base_framework.FindElement(driver,quantityInput,5);
            return qttyInput.GetAttribute("value");
        }

        public static void clickAddToCart(IWebDriver driver)
        {
            IWebElement addToCartEl = base_framework.FindElement(driver, addToCartBtn, 5);
            addToCartEl.Click();
        }
        public static String returnCartItemsQuantity(IWebDriver driver)
        {
            IWebElement cartCountEl = base_framework.FindElement(driver, cartCount, 10);
            return cartCountEl.Text.Split(" ")[0];
        }

        public static void goToCartPage(IWebDriver driver)
        {
            base_framework.FindElement(driver, CartMenu, 5).Click();
        }

        public static String returnProductTitle(IWebDriver driver)
        {
            return base_framework.FindElement(driver, productTitle, 5).Text;
        }
    }
}

﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;

using System;
using System.Collections.Generic;
using System.Text;

namespace dbinns_framework.Pages
{
    class home_page
    {
        static By welcomeMsg = By.XPath("//div//h1[contains(text(), 'Welcome')]");
        static By searchInput = By.XPath("//input[@id='woocommerce-product-search-field-0']");
        



        public static bool isPageLoaded(IWebDriver driver)
        {
            return base_framework.FindElement(driver,welcomeMsg,5).Displayed;
        }

        public static bool isSearchBoxDisplayed(IWebDriver driver)
        {
            return base_framework.FindElement(driver,searchInput,5).Displayed;

        }

        public static void searchProduct(IWebDriver driver, String text)
        {
            base_framework.sendKeys(driver, searchInput, text, true, 5);

        }

        public static String returnsearchFieldText(IWebDriver driver)
        {
            return base_framework.FindElement(driver, searchInput, 5).GetAttribute("value");

        }
       

    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;
using RestSharp;

using OpenQA;
using NUnit.Framework;
using RestSharp.Authenticators;

namespace dbinns_framework
{
    class api_main
    {
        [Test]
        public static void create_product()
        {
            var client = new RestClient("http://34.205.174.166");
            var request = new RestRequest("/wp-json/wc/v3/products", Method.POST);
            //request.RequestFormat = DataFormat.Json;
            //request.AddHeader("cache-control", "no-cache");
            //request.AddHeader("Authorization", "Basic c2hvcG1hbmFnZXI6YXhZMiByaW1jIFN6TzkgY29iZiBBWkJ3IE5Mblg=");
            //request.AddParameter("Password", "axY2 rimc SzO9 cobf AZBw NLnX");
            client.Authenticator = new HttpBasicAuthenticator("shopmanager", "axY2 rimc SzO9 cobf AZBw NLnX");

            //request.AddUrlSegment("productId", 200);
            //request.RequestFormat = DataFormat.Json;
            var content = client.Execute(request).Content;
            Console.WriteLine(content);

        }

        public static void delete_product(String id)
        {
            var client = new RestClient("http://34.205.174.166");
            var request = new RestRequest("/wp-json/wc/v3/products", Method.DELETE);
            client.Authenticator = new HttpBasicAuthenticator("shopmanager", "axY2 rimc SzO9 cobf AZBw NLnX");

            request.AddUrlSegment("id", id);
            //request.RequestFormat = DataFormat.Json;
            client.Execute(request);

        }

        public static void delete_coupon(String id)
        {
            var client = new RestClient("http://34.205.174.166");
            var request = new RestRequest("/wp-json/wc/v3/coupons", Method.DELETE);
            client.Authenticator = new HttpBasicAuthenticator("shopmanager", "axY2 rimc SzO9 cobf AZBw NLnX");

            request.AddUrlSegment("id", id);
            //request.RequestFormat = DataFormat.Json;
            client.Execute(request);

        }

    }
}
